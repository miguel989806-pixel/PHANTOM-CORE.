import socket
import os
import sqlite3
import secrets
import uuid
from pathlib import Path
from functools import wraps

from flask import (
    Flask, request, jsonify, session,
    send_from_directory, send_file
)
from werkzeug.security import generate_password_hash, check_password_hash
from werkzeug.utils import secure_filename

BASE = Path(__file__).resolve().parent.parent
DATA = BASE / "data"
UPLOADS = DATA / "uploads"
CONFIG = BASE / "config"
FRONTEND = BASE / "frontend"
DB = DATA / "phantom.db"
SECRET_FILE = CONFIG / "secret.key"

for folder in (DATA, UPLOADS, CONFIG):
    folder.mkdir(parents=True, exist_ok=True)

if not SECRET_FILE.exists():
    SECRET_FILE.write_text(secrets.token_hex(32))

app = Flask(__name__, static_folder=None)
app.secret_key = SECRET_FILE.read_text().strip()
app.config["MAX_CONTENT_LENGTH"] = 100 * 1024 * 1024
app.config["SESSION_COOKIE_HTTPONLY"] = True
app.config["SESSION_COOKIE_SAMESITE"] = "Lax"
app.config["SESSION_COOKIE_SECURE"] = False

def connect():
    db = sqlite3.connect(DB)
    db.row_factory = sqlite3.Row
    db.execute("PRAGMA foreign_keys = ON")
    return db

def initialize():
    with connect() as db:
        db.execute("""
            CREATE TABLE IF NOT EXISTS users (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                username TEXT UNIQUE NOT NULL,
                password_hash TEXT NOT NULL,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )
        """)
        db.execute("""
            CREATE TABLE IF NOT EXISTS files (
                id TEXT PRIMARY KEY,
                user_id INTEGER NOT NULL,
                filename TEXT NOT NULL,
                stored_name TEXT NOT NULL,
                size INTEGER NOT NULL,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY(user_id) REFERENCES users(id)
            )
        """)

initialize()

def error(message, code=400):
    return jsonify({"success": False, "error": message}), code

def authenticated(fn):
    @wraps(fn)
    def wrapper(*args, **kwargs):
        if "user_id" not in session:
            return error("Autenticacao necessaria", 401)
        return fn(*args, **kwargs)
    return wrapper

@app.get("/")
def home():
    return send_from_directory(FRONTEND, "index.html")

@app.get("/css/<path:filename>")
def frontend_css(filename):
    return send_from_directory(FRONTEND / "css", filename)

@app.get("/js/<path:filename>")
def frontend_js(filename):
    return send_from_directory(FRONTEND / "js", filename)

@app.get("/api/status")
def status():
    with connect() as db:
        users = db.execute("SELECT COUNT(*) FROM users").fetchone()[0]
    return jsonify({
        "system": "PHANTOM CORE OMEGA",
        "status": "online",
        "version": "2.0",
        "backend": "Flask",
        "database": "SQLite",
        "registration_available": users == 0
    })

@app.get("/api/setup")
def setup():
    with connect() as db:
        count = db.execute("SELECT COUNT(*) FROM users").fetchone()[0]
    return jsonify({"first_setup": count == 0})

@app.post("/api/register")
def register():
    data = request.get_json(silent=True) or {}
    username = str(data.get("username", "")).strip()
    password = str(data.get("password", ""))

    if len(username) < 3 or len(username) > 32:
        return error("Usuario deve ter entre 3 e 32 caracteres")

    if len(password) < 10:
        return error("A senha precisa ter pelo menos 10 caracteres")

    with connect() as db:
        count = db.execute("SELECT COUNT(*) FROM users").fetchone()[0]

        if count > 0:
            return error("Cadastro inicial ja realizado", 403)

        try:
            cursor = db.execute(
                "INSERT INTO users (username, password_hash) VALUES (?, ?)",
                (username, generate_password_hash(password))
            )
            user_id = cursor.lastrowid
        except sqlite3.IntegrityError:
            return error("Usuario ja existe")

    session.clear()
    session["user_id"] = user_id
    session["username"] = username

    return jsonify({"success": True, "username": username})

@app.post("/api/login")
def login():
    data = request.get_json(silent=True) or {}
    username = str(data.get("username", "")).strip()
    password = str(data.get("password", ""))

    with connect() as db:
        user = db.execute(
            "SELECT * FROM users WHERE username = ?",
            (username,)
        ).fetchone()

    if not user or not check_password_hash(
        user["password_hash"], password
    ):
        return error("Usuario ou senha incorretos", 401)

    session.clear()
    session["user_id"] = user["id"]
    session["username"] = user["username"]

    return jsonify({"success": True, "username": user["username"]})

@app.get("/api/me")
@authenticated
def me():
    return jsonify({
        "authenticated": True,
        "username": session["username"]
    })

@app.post("/api/logout")
@authenticated
def logout():
    session.clear()
    return jsonify({"success": True})

@app.get("/api/files")
@authenticated
def list_files():
    with connect() as db:
        rows = db.execute(
            """SELECT id, filename, size, created_at
               FROM files WHERE user_id = ?
               ORDER BY created_at DESC""",
            (session["user_id"],)
        ).fetchall()

    return jsonify({"files": [dict(row) for row in rows]})

@app.post("/api/upload")
@authenticated
def upload():
    uploaded = request.files.get("file")

    if not uploaded or not uploaded.filename:
        return error("Selecione um arquivo")

    original = secure_filename(uploaded.filename)

    if not original:
        return error("Nome de arquivo invalido")

    file_id = uuid.uuid4().hex
    stored = file_id + ".bin"
    destination = UPLOADS / stored

    uploaded.save(destination)
    size = destination.stat().st_size

    try:
        with connect() as db:
            db.execute(
                """INSERT INTO files
                   (id, user_id, filename, stored_name, size)
                   VALUES (?, ?, ?, ?, ?)""",
                (file_id, session["user_id"], original, stored, size)
            )
    except Exception:
        destination.unlink(missing_ok=True)
        raise

    return jsonify({
        "success": True,
        "id": file_id,
        "filename": original,
        "size": size
    }), 201

@app.get("/api/download/<file_id>")
@authenticated
def download(file_id):
    with connect() as db:
        item = db.execute(
            """SELECT * FROM files
               WHERE id = ? AND user_id = ?""",
            (file_id, session["user_id"])
        ).fetchone()

    if not item:
        return error("Arquivo nao encontrado", 404)

    return send_file(
        str(UPLOADS / item["stored_name"]),
        download_name=item["filename"],
        as_attachment=True
    )

@app.delete("/api/files/<file_id>")
@authenticated
def delete_file(file_id):
    with connect() as db:
        item = db.execute(
            """SELECT * FROM files
               WHERE id = ? AND user_id = ?""",
            (file_id, session["user_id"])
        ).fetchone()

        if not item:
            return error("Arquivo nao encontrado", 404)

        db.execute("DELETE FROM files WHERE id = ?", (file_id,))

    path = UPLOADS / item["stored_name"]
    path.unlink(missing_ok=True)

    return jsonify({"success": True})

@app.get("/api/diagnostics")
@authenticated
def diagnostics():
    with connect() as db:
        db.execute("SELECT 1").fetchone()
        count = db.execute(
            "SELECT COUNT(*) FROM files WHERE user_id = ?",
            (session["user_id"],)
        ).fetchone()[0]

    return jsonify({
        "server": "online",
        "database": "connected",
        "authentication": "active",
        "stored_files": count
    })


@app.get("/api/ps4/test-port")
@authenticated
def ps4_test_port():
    port = request.args.get("port", type=int)

    if port not in (2121, 9090):
        return jsonify({
            "online": False,
            "message": "Porta não permitida. Use 2121 ou 9090."
        }), 400

    ip = "192.168.15.58"

    try:
        with socket.create_connection((ip, port), timeout=3):
            return jsonify({
                "online": True,
                "ip": ip,
                "port": port,
                "message": f"PS4 acessível na porta {port}."
            })
    except OSError as exc:
        return jsonify({
            "online": False,
            "ip": ip,
            "port": port,
            "message": f"Sem conexão na porta {port}: {exc}"
        })

@app.errorhandler(413)
def too_large(e):
    return error("Arquivo maior que o limite de 100 MB", 413)

@app.errorhandler(500)
def server_error(e):
    return error("Erro interno do servidor", 500)

if __name__ == "__main__":
    print("PHANTOM CORE OMEGA - REAL SYSTEM")
    print("Banco SQLite:", DB)
    print("Servidor: http://127.0.0.1:5000")
    app.run(host="0.0.0.0", port=5000, debug=False)
