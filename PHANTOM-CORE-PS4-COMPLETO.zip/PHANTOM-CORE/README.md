# PHANTOM-CORE

- Aplicação web/servidor original: `frontend/` e `backend/`.
- Base de homebrew nativo PS4: `ps4-native/`.
- Instruções de build PS4: `ps4-native/README.md`.

Consulte `PS4-BUILD-STATUS.md` para o estado real da edição PS4.
