const PHANTOM = {
  name: "PHANTOM CORE Ω",
  version: "1.0.0",
  ps4: {
    ip: "192.168.15.58",
    ports: {
      ftp: 2121,
      binloader: 9090
    }
  },

  async testPort(port) {
    return {
      port,
      status: "Aguardando integração nativa"
    };
  }
};

console.log(PHANTOM.name, PHANTOM.version);
