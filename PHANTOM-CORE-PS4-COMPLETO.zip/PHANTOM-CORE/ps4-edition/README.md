# PHANTOM CORE Ω — PS4 Companion 1.0.1

## Estado desta entrega
Esta pasta contém uma edição web para abrir no navegador do PS4 e conectar ao Flask executado no celular pela mesma rede Wi-Fi. **Ainda não é um PKG nativo instalável.** O pacote PKG exige um executável PS4 e metadados gerados por um toolchain homebrew compatível; este ZIP não contém SDK/toolchain nem foi compilado em PKG.

## Iniciar o servidor no celular
No Termux, dentro da pasta do projeto:

```sh
cd ~/PHANTOM-CORE
python backend/server.py
```

O servidor já usa `host="0.0.0.0"` e porta `5000`, permitindo conexões da rede local. Descubra o IPv4 do celular nas configurações Wi-Fi do Android.

## Abrir no PS4
1. Conecte PS4 e celular à mesma rede Wi-Fi.
2. No PS4, abra o navegador e acesse `http://IP-DO-CELULAR:5000/`.
3. Para a edição companion separada, hospede `src/index.html` num servidor HTTP local ou copie-a para um host acessível na rede.
4. Informe `http://IP-DO-CELULAR:5000` no campo e selecione **TESTAR CONEXÃO**.

O endereço `192.168.1.100` no config é apenas exemplo; substitua pelo IPv4 real do celular.

## Observações
- O backend existente implementa `/api/status`, `/api/login`, `/api/me` e `/api/logout`.
- Os testes FTP/BinLoader dependem de serviços efetivamente ativos no PS4; não são simulados nesta edição.
- Não exponha a porta 5000 diretamente à internet. Use apenas rede local confiável.
- Para criar PKG nativo, será necessário instalar/configurar o OpenOrbis PS4 Toolchain num ambiente compatível e preencher `param.sfo`, `eboot.bin` e os recursos de sistema exigidos. O celular pode orquestrar uma compilação remota via CI, mas isso requer configurar o ambiente de build e validar a compatibilidade do console.
