function login(){
  const user=document.getElementById("username").value.trim();
  const pass=document.getElementById("password").value;
  if(!user||!pass){alert("Preencha usuário e senha.");return;}
  sessionStorage.setItem("phantom_user",user);
  document.getElementById("login").hidden=true;
  document.getElementById("app").hidden=false;
}

function logout(){
  sessionStorage.removeItem("phantom_user");
  location.reload();
}

function showPage(id){
  document.querySelectorAll(".page").forEach(p=>p.hidden=true);
  document.getElementById(id).hidden=false;
}

function listFiles(){
  const files=document.getElementById("files").files;
  const area=document.getElementById("fileList");
  if(!files.length){area.textContent="Selecione arquivos primeiro.";return;}
  area.innerHTML="";
  [...files].forEach(file=>{
    const item=document.createElement("p");
    item.textContent=file.name+" — "+(file.size/1024).toFixed(1)+" KB";
    area.appendChild(item);
  });
}

function checkMemory(){
  const output=document.getElementById("ram");
  if(performance.memory){
    output.textContent="Memória JavaScript usada pelo navegador: "+
      (performance.memory.usedJSHeapSize/1048576).toFixed(1)+" MB";
  }else{
    output.textContent="Medição de memória não suportada neste navegador.";
  }
}

function diagnose(){
  document.getElementById("diagnostic").textContent=
    "Interface: operacional | JavaScript: ativo | Navegador: "+
    navigator.userAgent;
}

function saveIP(){
  const ip=document.getElementById("ps4ip").value.trim();
  if(!ip){alert("Digite o IP do PS4.");return;}
  localStorage.setItem("phantom_ps4_ip",ip);
  document.getElementById("goldStatus").textContent=
    "Endereço salvo: "+ip+". Conexão ainda não testada.";
}

window.addEventListener("DOMContentLoaded",()=>{
  if(sessionStorage.getItem("phantom_user")){
    document.getElementById("login").hidden=true;
    document.getElementById("app").hidden=false;
  }
  const ip=localStorage.getItem("phantom_ps4_ip");
  if(ip){
    document.getElementById("ps4ip").value=ip;
    document.getElementById("goldStatus").textContent=
      "Endereço salvo: "+ip+". Conexão ainda não testada.";
  }
});
