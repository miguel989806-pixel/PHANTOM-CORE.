async function login(){
    if (!/PlayStation 4/i.test(navigator.userAgent || "")) {
        alert("Acesso exclusivo ao navegador do PS4.");
        return;
    }

    const usernameInput =
        document.getElementById("username") ||
        document.getElementById("user");
    const passwordInput = document.getElementById("password");

    if (!usernameInput || !passwordInput) {
        alert("Campos de login não encontrados.");
        return;
    }

    const username = usernameInput.value.trim();
    const password = passwordInput.value;

    try {
        const response = await fetch("/api/login", {
            method: "POST",
            headers: {"Content-Type": "application/json"},
            body: JSON.stringify({username, password})
        });

        const result = await response.json();

        if (!response.ok || !result.success) {
            alert(result.error || "Usuário ou senha incorretos.");
            return;
        }

        sessionStorage.setItem("phantom_user", result.username);
        document.getElementById("login").hidden = true;
        document.getElementById("app").hidden = false;

    } catch (error) {
        alert("Não foi possível conectar ao servidor.");
    }
}

function logout(){
  sessionStorage.removeItem("phantom_user");
  location.reload();
}

function showPage(id){
  document.querySelectorAll(".page").forEach(p=>p.hidden=true);
  document.getElementById(id).hidden=false;
}

function listFiles(){
  const files=document.getElementById("files").files;
  const area=document.getElementById("fileList");
  if(!files.length){area.textContent="Selecione arquivos primeiro.";return;}
  area.innerHTML="";
  [...files].forEach(file=>{
    const item=document.createElement("p");
    item.textContent=file.name+" — "+(file.size/1024).toFixed(1)+" KB";
    area.appendChild(item);
  });
}

function checkMemory(){
  const output=document.getElementById("ram");
  if(performance.memory){
    output.textContent="Memória JavaScript usada pelo navegador: "+
      (performance.memory.usedJSHeapSize/1048576).toFixed(1)+" MB";
  }else{
    output.textContent="Medição de memória não suportada neste navegador.";
  }
}


async function diagnose(){
    const output = document.getElementById("diagnosticResult");

    if (!output) {
        alert("Elemento diagnosticResult não encontrado.");
        return;
    }

    output.textContent = "Verificando servidor e conexão com o PS4...";

    try {
        const serverResponse = await fetch("/api/diagnostics", {
            credentials: "same-origin"
        });

        if (!serverResponse.ok) {
            throw new Error("Falha na autenticação ou no servidor.");
        }

        const server = await serverResponse.json();

        const ftpResponse = await fetch(
            "/api/ps4/test-port?port=2121",
            {credentials: "same-origin"}
        );
        const ftp = await ftpResponse.json();

        const binResponse = await fetch(
            "/api/ps4/test-port?port=9090",
            {credentials: "same-origin"}
        );
        const bin = await binResponse.json();

        output.textContent =
            "PHANTOM CORE Ω — DIAGNÓSTICO

" +
            "Servidor: " + server.server + "
" +
            "Banco SQLite: " + server.database + "
" +
            "Autenticação: " + server.authentication + "
" +
            "Arquivos: " + server.stored_files + "

" +
            "PS4: " + (ftp.ip || bin.ip || "192.168.15.58") + "
" +
            "FTP 2121: " + (ftp.online ? "ONLINE" : "OFFLINE") +
            "
" + ftp.message + "

" +
            "BinLoader 9090: " + (bin.online ? "ONLINE" : "OFFLINE") +
            "
" + bin.message;

    } catch (error) {
        output.textContent = "Erro no diagnóstico: " + error.message;
    }
}


function saveIP(){
  const ip=document.getElementById("ps4ip").value.trim();
  if(!ip){alert("Digite o IP do PS4.");return;}
  localStorage.setItem("phantom_ps4_ip",ip);
  document.getElementById("goldStatus").textContent=
    "Endereço salvo: "+ip+". Conexão ainda não testada.";
}

window.addEventListener("DOMContentLoaded",()=>{
  if(sessionStorage.getItem("phantom_user")){
    document.getElementById("login").hidden=true;
    document.getElementById("app").hidden=false;
  }
  const ip=localStorage.getItem("phantom_ps4_ip");
  if(ip){
    document.getElementById("ps4ip").value=ip;
    document.getElementById("goldStatus").textContent=
      "Endereço salvo: "+ip+". Conexão ainda não testada.";
  }
});

// PHANTOM CORE OMEGA - PS4 AUTO DETECT
(function () {
    function detectPS4() {
        const ua = navigator.userAgent || "";
        const isPS4 = /PlayStation 4/i.test(ua);

        if (!isPS4) return;

        document.documentElement.classList.add("ps4-mode");
        document.documentElement.dataset.platform = "ps4";

        if (document.body) {
            document.body.classList.add("ps4-mode");
        }

        let style = document.getElementById("phantom-ps4-style");

        if (!style) {
            style = document.createElement("style");
            style.id = "phantom-ps4-style";
            style.textContent = `
                .ps4-mode button,
                .ps4-mode input {
                    font-size: 20px !important;
                    min-height: 48px;
                }

                .ps4-mode button:focus,
                .ps4-mode a:focus,
                .ps4-mode input:focus {
                    outline: 3px solid #a78bfa !important;
                    outline-offset: 4px;
                }

                .ps4-mode {
                    scroll-behavior: smooth;
                }
            `;
            document.head.appendChild(style);
        }

        console.log("PHANTOM CORE: PS4 DETECTADO");
    }

    if (document.readyState === "loading") {
        document.addEventListener("DOMContentLoaded", detectPS4);
    } else {
        detectPS4();
    }
})();
