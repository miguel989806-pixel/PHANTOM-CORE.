# PHANTOM-CORE — PS4 native build starter

Esta pasta é uma base nativa de homebrew PS4 com OpenOrbis v0.5.4 e GitHub Actions.
O workflow executa a compilação em Linux x64 na nuvem; não usa QEMU no Android.

## O que está incluído
- `src/main.cpp`: aplicativo nativo inicial de teste (não é ainda a interface web completa).
- `Makefile`: compilação ELF/OELF, geração de `eboot.bin`, SFO, GP4 e PKG.
- `sce_sys/icon0.png`: ícone reutilizado do projeto enviado.
- `tools/make_gp4.py`: gerador do projeto GP4.
- `.github/workflows/build.yml`: pipeline de compilação remota.

## Como usar
1. Envie a pasta inteira `PHANTOM-CORE` para um repositório GitHub.
2. No GitHub, abra Actions e execute `Build PHANTOM-CORE PS4 PKG` (Run workflow).
3. Se a compilação terminar com sucesso, baixe o artefato `PHANTOM-CORE-PS4`.
4. Verifique o PKG antes de instalar no PS4.

## Limite importante
Esta é uma base de compilação nativa, não uma conversão automática do backend Flask e da interface web.
O `main.cpp` é apenas um bootstrap de teste. A interface completa, login, rede e funções do projeto
precisam ser portadas para APIs e bibliotecas compatíveis com PS4. O PKG só será considerado pronto
quando o GitHub Actions terminar com sucesso e o artefato `.pkg` existir.

Identidade provisória: `PHNTM0001`. Não use IDs de conteúdo de terceiros.
