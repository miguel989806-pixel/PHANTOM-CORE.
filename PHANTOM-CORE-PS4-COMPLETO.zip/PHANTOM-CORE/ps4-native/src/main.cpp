#include <orbis/libkernel.h>
#include <stdio.h>

int main(int argc, char* argv[]) {
    (void)argc;
    (void)argv;
    printf("PHANTOM-CORE PS4 native bootstrap\n");
    printf("Build successful. Native interface port is the next development step.\n");
    sceKernelUsleep(5000000);
    return 0;
}
