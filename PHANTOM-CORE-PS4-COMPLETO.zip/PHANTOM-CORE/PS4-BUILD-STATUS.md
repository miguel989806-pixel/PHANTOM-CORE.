# PHANTOM-CORE PS4 — estado do pacote de desenvolvimento

A pasta `ps4-native/` agora contém um projeto homebrew nativo inicial e workflow GitHub Actions
para compilar em Linux x64, evitando a execução do PkgTool x86-64 via QEMU no Android.

O executável nativo inicial é apenas um bootstrap de teste. A edição web/Flask original permanece
preservada nas pastas `frontend/` e `backend/`; ela ainda não foi portada para APIs nativas do PS4.
Nenhum PKG foi pré-gerado nesta entrega. A geração depende de executar o workflow e validar o resultado.
